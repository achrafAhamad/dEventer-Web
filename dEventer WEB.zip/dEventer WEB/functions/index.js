const functions = require('firebase-functions')
const admin = require('firebase-admin');

admin.initializeApp();


exports.enviarNotifiacion = functions.database.ref('/chat/{idplan}/{idmensaje}').onCreate(async(snap, context) => {
    const id_plan = context.params.idplan;
    const id_mensaje = context.params.idmensaje;
    console.log('ID PLAN: ' + id_plan)
    console.log('ID MENSAJE: ' + id_mensaje)

    var registrationTokens = [];

    var db = firebase.database();

    db.ref('chat').once('value', function(snapshot) {
        snapshot.forEach(function(childSnapshot) {
            childSnapshot.forEach(function(s) {
                registrationTokens.push(s.val().token);
            })
        });
    })

    console.log("ARRAY DE TOKEN: " + registrationTokens);

    admin.messaging().subscribeToTopic(registrationTokens, topic)
        .then(function(response) {
            console.log('Successfully subscribed to topic:', response);
        })
        .catch(function(error) {
            console.log('Error subscribing to topic:', error);
        });


    const payload = {
        to: id_plan,
        data: {
            title: 'titulo de notificación',
            body: 'mensaje de la notificacion'
        }
    };
    /*  const id = 'planes';
     const options = {
         priority: "high",
         timeToLive: 60 * 60 * 24
     }; */

    admin.messaging().send(payload);

    /* .then((response) => {
            console.log("Successfully sent message: ", response);
            return true;
        })
        .catch((error) => {
            console.log("Error sending message: ", error);
            return false;
        }); */
});