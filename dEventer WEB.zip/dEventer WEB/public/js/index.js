/* ---------------------------- */

function acceder() {

    var correo = document.getElementById("txtCorreo").value;
    var pass = document.getElementById("txtPass").value;


    firebase.auth().signInWithEmailAndPassword(correo, pass)
        .then(function() {
            location.href = "inicio.html";
            document.getElementById('alerta')
                .innerHTML = "<div class='alert alert-success' role='alert'>Usuario aceptado!</div>";
        })
        .catch(function(error) {
            var errorCode = error.code;
            var errorMessage = error.message;
            alert(errorCode + ": " + errorMessage);

        });

    return false;
}

function limpiar() {
    var correo = $('#txtCorreo');
    var pass = $('#txtPass');

    correo.val('');
    pass.val('');

    return false;
}