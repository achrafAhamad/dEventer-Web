function registrarse() {

    var nombre = document.getElementById('txtNombre').value;
    var apellido = document.getElementById('txtApellidos').value;
    var correo = document.getElementById("txtCorreo").value;
    var pass = document.getElementById("txtPass").value;
    var passx2 = document.getElementById("txtPassx2").value;
    var codpostal = document.getElementById("txtCodPostal").value;
    var fecha = document.getElementById("txtFecha").value;
    var sexo = document.getElementsByName("rsexo");
    var sexoChecked = "Hombre";
    for (i = 0; i < sexo.length; i++) {
        if (sexo[i].checked) {
            sexoChecked = sexo[i].value;
            break;
        }
    }

    var fechaNacimiento = new Date(fecha);
    var fechaSistema = new Date();
    var resta = fechaSistema - fechaNacimiento;
    var edad = (Math.floor(resta / ((60 * 60 * 24 * 1000)) / 365));


    if (validarPass(pass, passx2)) {
        firebase.auth().createUserWithEmailAndPassword(correo, pass)
            .then(function() {
                var idUser = firebase.auth().currentUser.uid;
                guardarDatosUsuario(idUser, codpostal, nombre, apellido, edad, correo, sexoChecked);
            })
            .catch(function(error) {
                mensajeError(error.message);
            });
    } else
        mensajeError("Las contraseñas no son iguales");

    return false;
}

function guardarDatosUsuario(idUser, codPostal, nombre, apellido, edad, correo, sexoChecked) {
    var db = firebase.database();
    db.ref(idUser).set({
        "cp": codPostal,
        "nombreUsuario": nombre.concat(" " + apellido),
        "edad": edad,
        "email": correo,
        "id": idUser,
        "planesApuntados": [],
        "sexo": sexoChecked

    }).then(function() {
        mensajeExito("Registrado con éxito");
        location.href = "inicio.html";
    }).catch((function(error) {
        alert(error);
    }));
}

function validarPass(pass, pass2) {
    if (pass === pass2)
        return true;
    else
        return false;
}

function mensajeExito(mensaje) {
    document.getElementById('alerta').innerHTML = "<div class='alert alert-success' role='alert'>" + mensaje + "</div>";
}

function mensajeError(mensaje) {
    document.getElementById('alerta').innerHTML = "<div class='alert alert-danger' role='alert'>" + mensaje + "</div>";
}

function limpiar() {
    var nombre = document.getElementById('txtNombre').value = '';
    var apellido = document.getElementById('txtApellidos').value = '';
    var correo = document.getElementById("txtCorreo").value = '';
    var pass = document.getElementById("txtPass").value = '';
    var passx2 = document.getElementById("txtPassx2").value = '';
    var codpostal = document.getElementById("txtCodPostal").value = '';
    var fecha = document.getElementById("txtFecha").value = '';

    return false;
}