function establecerCampos() {
    var nombre = localStorage.getItem("nombre");
    var imagen = localStorage.getItem("imagen");
    var nombre_creador_plan = localStorage.getItem("dueno");

    var imagen_plan_chat = document.getElementById('imagen-plan-chat');
    var nombre_plan_chat = document.getElementById('nombre-plan-chat');
    var nombre_creador = document.getElementById("nombre-creador");

    imagen_plan_chat.src = imagen;
    nombre_plan_chat.innerHTML = nombre;
    nombre_creador.innerHTML = "creado por " + nombre_creador_plan;

}

function filtrarNotificacion(id_usuario, nombre_usuario, mensaje, urlImagen) {
    var db = firebase.database();
    arrayToken = [];
    db.ref('tokens').on('value', function(snapshot) {

        snapshot.forEach(function(data) {
            var id = data.key;
            if (id !== id_usuario) {
                var tokenNotificacion = data.val().token;
                sendMessage(tokenNotificacion, nombre_usuario, mensaje, urlImagen);
            }
        });
    })
}

function enviarMensaje() {

    firebase.auth().onAuthStateChanged(function(user) {
        if (user) {
            var id_usuario = firebase.auth().currentUser.uid;
            var db = firebase.database();
            var storage = firebase.storage().ref(`/perfil/`);
            var mensaje = document.getElementById('txtMensaje');
            var fecha_sistema = new Date();
            var nombre_usuario = '';

            db.ref(id_usuario).on('value', function(snapshot) {
                datos = snapshot.val();
                nombre_usuario = datos.nombreUsuario;

                var urlImagen = '';
                storage.child(id_usuario + '/foto.jpg').getDownloadURL().then(function(url) {
                    if (url != null) {
                        urlImagen = url;
                    } else {
                        urlImagen = '../imagenes/deventer.png';
                    }

                    if (mensaje.value.length !== 0) {
                        var id_plan = localStorage.getItem('id_plan');

                        db.ref('chat').child(id_plan).push().set({
                            'fotoPerfil': urlImagen,
                            'id': id_usuario,
                            'hora': fecha_sistema.getHours() + ":" + fecha_sistema.getMinutes(),
                            'mensaje': mensaje.value,
                            'nombre': nombre_usuario
                        });
                        filtrarNotificacion(id_usuario, nombre_usuario, mensaje.value, urlImagen);
                        mensaje.value = '';
                    } else
                        console.log('debe escribir un mensaje');

                }).catch(function(error) {
                    console.log('no se ha cargado la imagen: ' + error);
                });

            });
        }
    });
    return false;
}
//tokenNotificacion, nombre_usuario, mensaje, urlImagen
function sendMessage(mi_token, titulo, mensaje, fotoPerfil) {
    var key = 'AAAAtn5NxnI:APA91bGxc4EPWBPGsJ-7n35Pu_RatGqcRZtyto6aXEa-hywUxzkRkpY2G_fZ1ot9SFrYog9DlicmBG_e3gMFA_-5RyG2LexMRvi7qKcLukET8_4eIsf8QZ7d1CFlgfdiC_G3Fjlcp57G';
    var to = mi_token;
    var notification = {
        'title': titulo,
        'body': mensaje,
        'icon': fotoPerfil
    };
    //'click_action': 'http://localhost:8081'


    fetch('https://fcm.googleapis.com/fcm/send', {
        'method': 'POST',
        'headers': {
            'Authorization': 'key=' + key,
            'Content-Type': 'application/json'
        },
        'body': JSON.stringify({
            'notification': notification,
            'to': to
        })
    }).then(function(response) {
        console.log("MENSAJE ENVIADO" + response);
    }).catch(function(error) {
        console.error(error);
    })
}


/* function enviarNotificacion() {
    messaging.usePublicVapidKey("AAAAtn5NxnI:APA91bGxc4EPWBPGsJ-7n35Pu_RatGqcRZtyto6aXEa-hywUxzkRkpY2G_fZ1ot9SFrYog9DlicmBG_e3gMFA_-5RyG2LexMRvi7qKcLukET8_4eIsf8QZ7d1CFlgfdiC_G3Fjlcp57G");
    Notification.requestPermission().then((permission) => {
        if (permission === 'granted') {
            console.log('Permiso concedido');
            messaging.getToken().then((currentToken) => {
                console.log("aqui me devolveria el token");
            });
        } else {
            console.log('Permiso denegado');
        }
    });
} */


function cargarMensaje() {
    var id_plan = localStorage.getItem('id_plan');
    var db = firebase.database();

    db.ref('chat').child(id_plan).on('child_added', function(snapshot) {

        var control = '';
        var id_usuario = firebase.auth().currentUser.uid;
        if (id_usuario === snapshot.val().id) {
            control = `
        <div class = "container justify-content-center align-items-cente mb-5 animated bounce">
        <div class="container card m-2 p-2 mr-5 bg-primary" style = "width:100%"><li class="d-flex mb-2 pb-3 p-2" id='${snapshot.key}'>
        <img id = "img-usuario-chat" src='${snapshot.val().fotoPerfil}' alt="avatar" class="avatar rounded-circle mr-2 ml-lg-3 ml-0 z-depth-1" width = "50px" height = "50px">
        <div class="chat-body white ml-2 z-depth-1">
            <div class="header">
                <strong id = "nombreUser" class="primary-font">${snapshot.val().nombre}</strong>
            </div>
            <hr>
            <p id = "linea-mensaje" class="mb-4 text-white">
                ${snapshot.val().mensaje}
            </p>
            
        </div>
        </li>
        <small id = 'horaUser' class="pull-right text-white"><i class="fa fa-history"> Enviado a las ${snapshot.val().hora}</i></small>
        </div> 
        </div>
      `
        } else {
            control = `
            <div class = "container justify-content-center align-items-cente mb-5">
            <div class="container card m-2 p-2 mr-5" style = "width:100%"><li class="d-flex mb-2 pb-3 p-2" id='${snapshot.key}'>
            <img id = "img-usuario-chat" src='${snapshot.val().fotoPerfil}' alt="avatar" class="avatar rounded-circle mr-2 ml-lg-3 ml-0 z-depth-1" width = "50px" height = "50px">
            <div class="chat-body white ml-2 z-depth-1">
                <div class="header">
                    <strong id = "nombreUser" class="primary-font">${snapshot.val().nombre}</strong>
                </div>
                <hr>
                <p id = "linea-mensaje" class="mb-4 text-info">
                    ${snapshot.val().mensaje}
                </p>
                
            </div>
            </li>
            <small id = 'horaUser' class="pull-right text-muted"><i class="fa fa-history"> Enviado a las ${snapshot.val().hora}</i></small>
            </div> 
            </div>
          `
        }
        $("#mensajes").append(control);
        $(window).scrollTop($("#mensajes").prop('scrollHeight'));
    });
}


/*  <div class="card m-2 p-2 mb-4 ml-5" style = "width:100%"><li class="d-flex mb-2 pb-3 p-2" id='${snapshot.key}'>
        <img id = "img-usuario-chat" src='${snapshot.val().fotoPerfil}' alt="avatar" class="avatar rounded-circle mr-2 ml-lg-3 ml-0 z-depth-1" width = "50px" height = "50px">
        <div class="chat-body white ml-2 z-depth-1">
            <div class="header">
                <strong id = "nombreUser" class="primary-font">${snapshot.val().nombre}</strong>
            </div>
            <hr>
            <p id = "linea-mensaje" class="mb-4 text-info">
                ${snapshot.val().mensaje}
            </p>
            
        </div>
        </li>
        <small id = 'horaUser' class="pull-right text-muted"><i class="fa fa-history"> Enviado a las ${snapshot.val().hora}</i></small>
        </div> */



function cargarFunciones() {
    establecerCampos();
    cargarMensaje();
}