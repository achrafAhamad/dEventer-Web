function leerDatos() {
    var db = firebase.firestore();

    db.collection("planes").get().then(function(querySnapshot) {

        var li;
        if (querySnapshot.size != 0) {

            querySnapshot.forEach(function(doc) {
                li = document.createElement("li");
                li.className = "list-group-item m-4 animated zoomIn";

                var valor = doc.data().plan;

                var id = doc.id;

                var descripcion = valor.descripcion;
                var dueno = valor.dueno;
                var fecha = valor.fecha;
                var hora = valor.hora;
                var imagen = valor.imagen;
                var imagenDueno = valor.imagen_dueno;
                var precio = valor.precio;
                var nombre = valor.nombre;
                var ubicacion = valor.ubicacion;
                var usuarios_apuntados = valor.usuarios_apuntados;

                if (typeof usuarios_apuntados === 'undefined') {
                    usuarios_apuntados = [];
                }

                li.id = "li-" + id;
                li.innerHTML = `
            <h4 id = 'titulo' class='card-title p-2'>${nombre}</h4>
            <img id = 'imagenplan' class='img-thumbnail bg-dark m-auto' src=${imagen} alt='imagen del plan '>
          
            
            <a href = 'map.html' id = 'ubicacion-${id}' target='_blank' class='list-group-item  p-2 m-2 '><i class='fa fa-map-marker '></i> ${ubicacion}</a>
            <label id = 'fecha' class='list-group-item p-2 m-2 '><i class='fa fa-calendar'></i> ${fecha}</label>
            <label id = 'hora' class='list-group-item p-2 m-2'><i class='fa fa-hourglass-start'></i> ${hora}</label>
            <label id = 'precio' class='list-group-item p-2 m-2'><i class='fa fa-euro'></i> ${precio}</label>
            <label id = 'usuarios' class='list-group-item p-2 m-2'><i class='fa fa-users'></i> ${usuarios_apuntados.length}</label>
              
            <div>
                <label class="list-group-item p-2 m-2 text-primary" type="button" data-toggle="collapse" data-target="#${id}" aria-expanded="true" aria-controls="${id}" data-parent = "#${id}">
                <i class="fa fa-info"></i> Dame click para ver la descripción del plan
                </label>
            </div>
            
            <div class="collapse p-2 m-2 animated zoomIn" id="${id}">
            <div class="card card-body text-info p-2 m-2">
                <img class = 'm-2' width = "50px" heigth = "50px" src="${imagenDueno}" alt="imagen del dueño">
                <h6 class = 'font-weight-bold p-2 m-2'>${dueno} </h6>
                <p class = 'card bg-info p-2 text-white m-2'>${descripcion}</p>
            </div>
        </div>

        <div style = "visibility: hidden" id = "divprogress-${id}" class="progress">
            <div id = "miprogress-${id}" class="progress-bar bg-success" style="width:0%"></div>
        </div>

        <button id = 'btnApuntarse-${id}' class='btn btn-primary m-2 active' >Apuntarse al plan </button>
            `;
                document.getElementById("lista").appendChild(li);

                //paso de variable de una pagina a otra, funciona como el intent.putExtra de Android
                $('a#ubicacion-' + id).on('click', function() {
                    localStorage.setItem("ubicacion", ubicacion);
                    console.log(ubicacion)
                });


                /* CLICK DEL BOTON DE CADA PLAN */
                $("#li-" + id + " #btnApuntarse-" + id).bind("click", function(e) {
                    var mi_token = '';
                    var messaging = firebase.messaging();
                    messaging.requestPermission()
                        .then(function() {
                            // console.log('permiso de notificaciones aceptado.')
                            messaging.getToken()
                                .then(function(token) {
                                    if (token) {
                                        mi_token = token;
                                        agregarToken(mi_token)
                                    }
                                })
                                .catch(function(err) {
                                    console.log("ERROR: " + err);
                                });
                        })
                        .catch(function(err) {
                            console.log('Debe aceptar los permisos de notificaciones', err);
                        });

                    apuntarseAlPlan(id);
                    apuntarseUsuario(id, descripcion, dueno, fecha, hora, imagen, imagenDueno, precio, nombre, ubicacion, usuarios_apuntados);

                    var miprogress = document.getElementById('miprogress-' + id);
                    var divprogress = document.getElementById('divprogress-' + id);

                    divprogress.style.visibility = "visible";
                    miprogress.style.width = "100%";

                    //hago un sleep y vuelvo a ocultar el progress
                    var espera = 1000;
                    setTimeout(function() {
                        divprogress.style.visibility = "hidden";
                        irPlanes();
                    }, espera);

                    var botonApuntados = document.getElementById('btnApuntarse-' + id);
                    botonApuntados.innerHTML = 'Apuntado, que te diviertas😊'
                    botonApuntados.setAttribute("disabled", "");

                    $('#btnApuntarse-' + id).removeClass("btn btn-primary m-2");
                    $('#btnApuntarse-' + id).addClass("btn btn-secondary m-2");

                });
            })
            planesExistentes()

        } else {
            li = document.createElement("li");
            li.className = "list-group-item m-4 animated zoomIn";
            li.innerHTML = `
            <h4 id = 'titulo' class='card-title p-2 text-center text-danger h2'>Parece que no hay planes disponibles 😬</h4>
            <img id = 'imagenplan' class='img-thumbnail bg-dark m-auto' src='imagenes/error.jpg' alt='imagen del plan '>
          `
            document.getElementById("lista").appendChild(li);
        }

    }).catch(function(error) {
        console.log(error)
    });
    return false;
}

function agregarToken(token_usuario) {
    firebase.auth().onAuthStateChanged(function(user) {
        if (user) {
            var db = firebase.database();

            db.ref('tokens/' + user.uid).set({
                token: token_usuario
            });
        }
    });
}

//COMRPOBAMOS SI EL USUARIO YA ESTÁ APUNTADO AL PLAN
function planesExistentes() {

    var id_usuario = firebase.auth().currentUser.uid;
    var dbf = firebase.firestore();
    dbf.collection("planes").where("plan.usuarios_apuntados", "array-contains", id_usuario) //
        .get()
        .then(function(querySnapshot) {
            querySnapshot.forEach(function(doc) {

                var valor = doc.data().plan;
                var id_plan = doc.id;

                var botonApuntados = document.getElementById('btnApuntarse-' + id_plan);


                if (querySnapshot.size !== 0) {

                    botonApuntados.innerHTML = 'Apuntado, que te diviertas 😊 '
                    botonApuntados.setAttribute("disabled", "");
                    // botonApuntados.style.backgroundColor = '#A3A4A3';
                    $('#btnApuntarse-' + id_plan).removeClass("btn btn-primary m-2");
                    $('#btnApuntarse-' + id_plan).addClass("btn btn-secondary m-2");

                } else {
                    botonApuntados.innerHTML = 'Apuntarse al plan '
                        //botonApuntados.removeAttribute("disabled");
                        // botonApuntados.style.backgroundColor = '#A3A4A3';
                    $('#btnApuntarse-' + id_plan).removeClass("btn btn-secondary m-2");
                    $('#btnApuntarse-' + id_plan).addClass("btn btn-primary m-2");

                }
            })
        }).catch(function(error) {
            console.log(error);
        });

}


function irPerfil() {
    ocultarFormulario();
    ocultarLista();
    ocultarChat();

    mostrarPerfil();
    cargarDatosPerfil();
}

function mostrarPerfil() {
    var contenedor_perfil = document.getElementById('contenedor-perfil');
    contenedor_perfil.style.display = 'block';
    contenedor_perfil.className = 'animated zoomIn';
}

function actualizarPerfil() {
    var imagen_perfil = document.getElementById('imagenperfil');
    var id_usuario = firebase.auth().currentUser.uid;
    var storage = firebase.storage().ref(`/perfil`);

    storage.child(id_usuario + "/foto.jpg").putString(imagen_perfil.src, 'data_url')
        .then(function(snapshot) {
            mensajeExitoPerfil('imagen del perfil cambiada con éxito');
        }).catch(function(error) {
            mensajeErrorPerfil(error);
        });

}

function cargarDatosPerfil() {
    var imagen_perfil = document.getElementById('imagenperfil');
    var nombre_apellido = document.getElementById('nombre-apellido');
    var edad = document.getElementById('edad');
    var sexo = document.getElementById('sexo');
    var cp = document.getElementById('cp');
    var correo = document.getElementById('correo');


    firebase.auth().onAuthStateChanged(function(user) {
        var db = firebase.database();
        var storage = firebase.storage();
        if (user) {
            var id_usuario = user.uid;
            db.ref(id_usuario).on('value', function(snapshot) {
                var datos = snapshot.val();

                nombre_apellido.innerHTML = `${datos.nombreUsuario}`;
                edad.innerHTML = `${datos.edad}`;
                sexo.innerHTML = `${datos.sexo}`;
                cp.innerHTML = `${datos.cp}`;
                correo.innerHTML = `${datos.email}`;

                var storageRef = storage.ref(`/perfil/`);
                storageRef.child(id_usuario + "/foto.jpg").getDownloadURL().then(function(url) {

                    if (url != null)
                        imagen_perfil.src = url;
                    else
                        imagen_perfil.src = "imagenes/deventer.png";

                }).catch(function(error) {
                    imagen_perfil.src = "imagenes/deventer.png";

                });

            });

        }

    });


    return false;
}

function cerrarSesion() {
    var sesion = firebase.auth();
    var opcion = confirm("¿Seguro que desea cerrar sesión?");
    if (opcion == true) {
        sesion.signOut();
        window.location.href = 'index.html';
    }
}

function ocultarPerfil() {
    var contenedor_perfil = document.getElementById('contenedor-perfil');
    contenedor_perfil.style.display = 'none';
}

function mostrarChat() {
    refrescarPlanes();
    document.getElementById("lista").style.display = "block";
    var db = firebase.firestore();
    var id_usuario = firebase.auth().currentUser.uid;

    db.collection("planes").where("plan.usuarios_apuntados", "array-contains", id_usuario)
        .get()
        .then(function(querySnapshot) {


            if (querySnapshot.size != 0) {
                querySnapshot.forEach(function(doc) {

                    var valor = doc.data().plan;

                    var id = doc.id;
                    var descripcion = valor.descripcion;
                    var dueno = valor.dueno;
                    var fecha = valor.fecha;
                    var hora = valor.hora;
                    var imagen = valor.imagen;
                    var imagenDueno = valor.imagen_dueno;
                    var precio = valor.precio;
                    var nombre = valor.nombre;
                    var ubicacion = valor.ubicacion;
                    var usuarios_apuntados = valor.usuarios_apuntados;


                    var li = document.createElement("li");
                    li.className = "list-group-item m-4 animated zoomIn";
                    li.id = "li-" + id;

                    li.innerHTML = `
                <h4 id = 'titulo' class='card-title p-2'>${nombre}</h4>
                <img id = 'imagenplan' class='img-thumbnail bg-dark m-auto' src=${imagen} alt='imagen del plan '>
              
                
                <a href = 'map.html' id = 'ubicacion-${id}' target='_blank' class='list-group-item  p-2 m-2 '><i class='fa fa-map-marker '></i> ${ubicacion}</a>
                <label id = 'fecha' class='list-group-item p-2 m-2 '><i class='fa fa-calendar'></i> ${fecha}</label>
                <label id = 'hora' class='list-group-item p-2 m-2'><i class='fa fa-hourglass-start'></i> ${hora}</label>
                <label id = 'precio' class='list-group-item p-2 m-2'><i class='fa fa-euro'></i> ${precio}</label>
                <label id = 'precio' class='list-group-item p-2 m-2'><i class='fa fa-users'></i> ${usuarios_apuntados.length}</label>
                  
                <div>
                    <label class="list-group-item p-2 m-2 text-primary" type="button" data-toggle="collapse" data-target="#${id}" aria-expanded="true" aria-controls="${id}" data-parent = "#${id}">
                    <i class="fa fa-info"></i> Dame click para ver la descripción del plan
                    </label>
                </div>
                
                <div class="collapse p-2 m-2 animated zoomIn" id="${id}">
                <div class="card card-body text-info p-2 m-2">
                    <img class = 'm-2' width = "50px" heigth = "50px" src="${imagenDueno}" alt="imagen del dueño">
                    <h6 class = 'font-weight-bold p-2 m-2'>${dueno} </h6>
                    <p class = 'card bg-info p-2 text-white m-2'>${descripcion}</p>
                </div>
            </div>
    
            <div style = "visibility: hidden" id = "divprogress" class="progress">
                <div id = "miprogress" class="progress-bar bg-success" style="width:0%"></div>
            </div>
    
            <button id = 'btnChatear-${id}' class='btn btn-success m-2 active' > Ir al chat </button>
                `;
                    document.getElementById("lista").appendChild(li);

                    $("#li-" + id + " #btnChatear-" + id).bind("click", function(e) {
                        console.log('chatear clickeado')
                        localStorage.setItem("nombre", nombre);
                        localStorage.setItem("imagen", imagen);
                        localStorage.setItem("id_plan", id);
                        localStorage.setItem("dueno", dueno);
                        setTimeout(() => {
                            location.href = "chat.html";
                        }, 200);
                    });
                });


            } else {
                var li = document.createElement("li");
                li.className = "list-group-item m-4 animated zoomIn";
                li.innerHTML = `
                <h4 id = 'titulo' class='card-title p-2 text-center text-danger h2'>Parece que aun no te has apuntado a ningún plan para chatear 😬</h4>
                <img id = 'imagenplan' class='img-thumbnail bg-dark m-auto' src='imagenes/error.jpg' alt='imagen del plan '>
              `
                document.getElementById("lista").appendChild(li);
            }
        }).catch(function(error) {
            console.log(error);
        });
}

function ocultarChat() {

}


function mostrarMisPlanes() {
    refrescarPlanes();
    document.getElementById("lista").style.display = "block";
    var db = firebase.firestore();
    var id_usuario = firebase.auth().currentUser.uid;

    db.collection("planes").where("plan.usuarios_apuntados", "array-contains", id_usuario)
        .get()
        .then(function(querySnapshot) {


            if (querySnapshot.size != 0) {
                querySnapshot.forEach(function(doc) {

                    var valor = doc.data().plan;

                    var id = doc.id;
                    var descripcion = valor.descripcion;
                    var dueno = valor.dueno;
                    var fecha = valor.fecha;
                    var hora = valor.hora;
                    var imagen = valor.imagen;
                    var imagenDueno = valor.imagen_dueno;
                    var precio = valor.precio;
                    var nombre = valor.nombre;
                    var ubicacion = valor.ubicacion;
                    var usuarios_apuntados = valor.usuarios_apuntados;




                    var li = document.createElement("li");
                    li.className = "list-group-item m-4 animated zoomIn";
                    li.id = "li-" + id;

                    li.innerHTML = `
                <h4 id = 'titulo' class='card-title p-2'>${nombre}</h4>
                <img id = 'imagenplan' class='img-thumbnail bg-dark m-auto' src=${imagen} alt='imagen del plan '>
              
                
                <a href = 'map.html' id = 'ubicacion-${id}' target='_blank' class='list-group-item  p-2 m-2 '><i class='fa fa-map-marker '></i> ${ubicacion}</a>
                <label id = 'fecha' class='list-group-item p-2 m-2 '><i class='fa fa-calendar'></i> ${fecha}</label>
                <label id = 'hora' class='list-group-item p-2 m-2'><i class='fa fa-hourglass-start'></i> ${hora}</label>
                <label id = 'precio' class='list-group-item p-2 m-2'><i class='fa fa-euro'></i> ${precio}</label>
                <label id = 'precio' class='list-group-item p-2 m-2'><i class='fa fa-users'></i> ${usuarios_apuntados.length}</label>
                  
                <div>
                    <label class="list-group-item p-2 m-2 text-primary" type="button" data-toggle="collapse" data-target="#${id}" aria-expanded="true" aria-controls="${id}" data-parent = "#${id}">
                    <i class="fa fa-info"></i> Dame click para ver la descripción del plan
                    </label>
                </div>
                
                <div class="collapse p-2 m-2 animated zoomIn" id="${id}">
                <div class="card card-body text-info p-2 m-2">
                    <img class = 'm-2' width = "50px" heigth = "50px" src="${imagenDueno}" alt="imagen del dueño">
                    <h6 class = 'font-weight-bold p-2 m-2'>${dueno} </h6>
                    <p class = 'card bg-info p-2 text-white m-2'>${descripcion}</p>
                </div>
            </div>
    
            <div style = "visibility: hidden" id = "divprogress" class="progress">
                <div id = "miprogress" class="progress-bar bg-success" style="width:0%"></div>
            </div>
    
            <button id = 'btnDesapuntarse-${id}' class='btn btn-danger m-2 active' > Desapuntarse del plan </button>
                `;
                    document.getElementById("lista").appendChild(li);

                    $("#li-" + id + " #btnDesapuntarse-" + id).bind("click", function(e) {
                        console.log('desapuntarse clickeado')
                        desapuntarseDelPlan(id);
                        desapuntarseUsuario(id, descripcion, dueno, fecha, hora, imagen, imagenDueno, precio, nombre, ubicacion, usuarios_apuntados);
                        $("#li-" + id).removeClass('list-group-item m-4 animated zoomIn');
                        $("#li-" + id).addClass('list-group-item m-4 animated rollOut');
                        setTimeout(() => {
                            irMisPlanes();
                        }, 200);
                    });
                });


            } else {
                var li = document.createElement("li");
                li.className = "list-group-item m-4 animated zoomIn";
                li.innerHTML = `
                <h4 id = 'titulo' class='card-title p-2 text-center text-danger h2'>Parece que aun no te has apuntado a ningún plan 😬</h4>
                <img id = 'imagenplan' class='img-thumbnail bg-dark m-auto' src='imagenes/error.jpg' alt='imagen del plan '>
              `
                document.getElementById("lista").appendChild(li);
            }
        }).catch(function(error) {
            console.log(error);
        });
    return false;
}



function irPlanes() {
    ocultarFormulario();
    ocultarPerfil();
    ocultarChat();

    mostrarLista();
    refrescarPlanes();

    return false;
}

function irChat() {
    ocultarPerfil();
    ocultarFormulario();
    ocultarLista();

    mostrarChat();
    return false;
}


function irMisPlanes() {
    ocultarFormulario();
    ocultarLista();
    ocultarPerfil();
    mostrarMisPlanes();
    return false;
}


function irCreaPlan() {
    ocultarChat();
    ocultarPerfil();
    ocultarLista();

    mostrarFormulario();
    return false;
}

function ocultarFormulario() {
    document.getElementById("formulario").style.display = "none";
    return false;
}

function mostrarFormulario() {
    document.getElementById("formulario").style.display = "block";
    return false;
}

function refrescarPlanes() {
    var lista = document.getElementById("lista");
    while (lista.firstChild) {
        lista.removeChild(lista.firstChild);
    }
}

function ocultarLista() {
    document.getElementById("lista").style.display = "none";
    return false;
}

function mostrarLista() {
    document.getElementById("lista").style.display = "block";
    leerDatos();
    return false;
}

function mensajeExitoCreaPlan(mensaje) {
    document.getElementById('alerta').innerHTML = "<div class='alert alert-success' role='alert'>" + mensaje + "</div>";
}

function mensajeErrorCreaPlan(mensaje) {
    document.getElementById('alerta').innerHTML = "<div class='alert alert-danger' role='alert'>" + mensaje + "</div>";
}


function mensajeErrorPerfil(mensaje) {
    document.getElementById('alertaPerfil').innerHTML = "<div class='alert alert-danger' role='alert'>" + mensaje + "</div>";
}

function mensajeExitoPerfil(mensaje) {
    document.getElementById('alertaPerfil').innerHTML = "<div class='alert alert-success' role='alert'>" + mensaje + "</div>";
}


function quitarElementos() {
    var contenedor = document.getElementById("contenedor");
    while (contenedor.firstChild) {
        contenedor.removeChild(contenedor.firstChild);
    }
}

function abrirGaleriaPerfil() {
    if (window.File && window.FileReader && window.FileList && window.Blob) {
        var explorador_perfil = document.getElementById("explorador-perfil");
        var texto_explorador_perfil = document.getElementById('texto-explorador-perfil');
        explorador_perfil.onchange = function(e) {

            // Creamos el objeto de la clase FileReader
            let reader = new FileReader();

            // Leemos el archivo subido y se lo pasamos a nuestro fileReader
            reader.readAsDataURL(e.target.files[0]);

            // Le decimos que cuando este listo ejecute el código interno
            reader.onload = function() {
                let img = document.getElementById('imagenperfil');
                img.src = reader.result;
                texto_explorador_perfil.style.whiteSpace = 'nowrap';
                texto_explorador_perfil.style.overflow = 'hidden';
                texto_explorador_perfil.style.textOverflow = 'ellipsis';
                texto_explorador_perfil.innerHTML = `${img.src}`

                var alertaImagenPerfil = document.getElementById('imagenCambiadaPerfil');
                alertaImagenPerfil.innerHTML = `
                <div class="alert alert-warning alert-dismissible fade show animated fadeIn" role="alert">
                    <p>Imagen del perfil cambiada con éxito</p>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                `;


            };
        }
    } else
        alert('El navegador no admite este sistema de ficheros, por favor escoja otro navegador web.');
}

function abrirGaleria() {
    if (window.File && window.FileReader && window.FileList && window.Blob) {
        var explorador = document.getElementById("explorador");
        var textoExplorador = document.getElementById('textoExplorador');
        explorador.onchange = function(e) {

            // Creamos el objeto de la clase FileReader
            let reader = new FileReader();

            // Leemos el archivo subido y se lo pasamos a nuestro fileReader
            reader.readAsDataURL(e.target.files[0]);

            // Le decimos que cuando este listo ejecute el código interno
            reader.onload = function() {
                let img = document.getElementById('imgPlan');
                img.src = reader.result;
                textoExplorador.style.whiteSpace = 'nowrap';
                textoExplorador.style.overflow = 'hidden';
                textoExplorador.style.textOverflow = 'ellipsis';
                textoExplorador.innerHTML = `${img.src}`

                var alertaImagen = document.getElementById('imagenCambiada');
                alertaImagen.innerHTML = `
                <div class="alert alert-warning alert-dismissible fade show animated fadeIn" role="alert">
                    <p>Imagen cambiada con éxito</p>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                `;

            };
        }
    } else
        alert('El navegador no admite este sistema de ficheros, por favor escoja otro navegador web.');
}

function guardarPlan() {

    var nombre = document.getElementById('txtNombrePlan').value;
    var imagen = document.getElementById('imgPlan');
    var ubicacion = document.getElementById('txtUbicacionPlan').value;
    var fecha = document.getElementById('txtFechaPlan').value;
    var hora = document.getElementById('txtHoraPlan').value;
    var precio = document.getElementById('txtPrecioPlan').value;
    var descripcion = document.getElementById('txtDescripcionPlan').value;

    var imagen_dueno = '';
    var dueno = '';

    fecha = moment(fecha).format('DD/MM/YYYY');
    var rutaImagen = imagen.src;


    var storage = firebase.storage();
    var id_usuario = firebase.auth().currentUser.uid;

    var storageRef = storage.ref(`/perfil/`);
    storageRef.child(id_usuario + "/foto.jpg").getDownloadURL().then(function(url) {

        if (url != null)
            imagen_dueno = url;

        var databaseR = firebase.database();
        var db = firebase.firestore();
        var ref = db.collection("planes");
        databaseR.ref(id_usuario).once('value')
            .then(function(snapshot) {
                var fila = snapshot.val();
                dueno = fila.nombreUsuario;

                var plan = {
                    "nombre": nombre,
                    "imagen": rutaImagen,
                    "ubicacion": ubicacion,
                    "fecha": fecha,
                    "hora": hora,
                    "imagen_dueno": imagen_dueno,
                    "dueno": dueno,
                    "precio": precio,
                    "descripcion": descripcion,
                    "usuarios_apuntados": []
                }
                ref.add({
                    plan
                }).then(function(doc) {
                    var storage = firebase.storage().ref(`/imgplanes`);

                    storage.child(doc.id + "/imagen.jpg").putString(imagen.src, 'data_url')
                        .then(function() {});
                    mensajeExitoCreaPlan('Plan creado con éxito');
                    restablecerCampos();
                }).catch(function(error) {
                    mensajeErrorCreaPlan(error);
                });
            });
    });

    return false;
}

function restablecerCampos() {
    document.getElementById('textoExplorador').innerHTML = `Escoger imagen`;
    document.getElementById('txtNombrePlan').value = '';
    document.getElementById('imgPlan').src = "imagenes/logo.png";
    document.getElementById('txtUbicacionPlan').value = '';
    document.getElementById('txtFechaPlan').value = '';
    document.getElementById('txtHoraPlan').value = '';
    document.getElementById('txtPrecioPlan').value = '';
    document.getElementById('txtDescripcionPlan').value = '';

    return false;
}


function apuntarseAlPlan(id_plan) {
    var id_usuario = firebase.auth().currentUser.uid;
    var db = firebase.database();

    db.ref(id_usuario).once('value', function(snapshot) {
        var datos = snapshot.val();
        var cp = datos.cp;
        var nombre = datos.nombreUsuario;
        var edad = datos.edad;
        var id = datos.id;
        var email = datos.email;
        var planesApuntados = datos.planesApuntados;
        var sexo = datos.sexo;

        if (typeof planesApuntados === 'undefined')
            planesApuntados = [];

        planesApuntados.push(id_plan);

        db.ref(id_usuario).set({
            "cp": cp,
            "nombreUsuario": nombre,
            "edad": edad,
            "email": email,
            "id": id,
            "planesApuntados": planesApuntados,
            "sexo": sexo

        }).then(function() {

        }).catch((function(error) {
            alert(error);
        }));

    });
}


function subscribirATopic(token, topic) {
    var key = 'AAAAtn5NxnI:APA91bGxc4EPWBPGsJ-7n35Pu_RatGqcRZtyto6aXEa-hywUxzkRkpY2G_fZ1ot9SFrYog9DlicmBG_e3gMFA_-5RyG2LexMRvi7qKcLukET8_4eIsf8QZ7d1CFlgfdiC_G3Fjlcp57G';
    fetch('https://iid.googleapis.com/iid/v1/' + token + '/rel/topics/' + topic, {
        method: 'POST',
        headers: new Headers({
            'Authorization': 'key=' + key,
            'Content-Type': 'application/json'
        })
    }).then(response => {
        if (response.status < 200 || response.status >= 400) {
            throw 'Error durante la subscripcion al topico del usuario: ' + response.status + ' - ' + response.text();
        }
        console.log('Usuario subscrito al topic "' + topic + '"');
    }).catch(error => {
        console.error(error);
    })
}




function desapuntarseDelPlan(id_plan) {
    var id_usuario = firebase.auth().currentUser.uid;
    var db = firebase.database();

    db.ref(id_usuario).once('value', function(snapshot) {
        var datos = snapshot.val();
        var cp = datos.cp;
        var nombre = datos.nombreUsuario;
        var edad = datos.edad;
        var id = datos.id;
        var email = datos.email;
        var planesApuntados = datos.planesApuntados;
        var sexo = datos.sexo;
        if (typeof planesApuntados === 'undefined')
            planesApuntados = [];

        planesApuntados = eliminarItemArray(planesApuntados, id_plan);

        db.ref(id_usuario).set({
            "cp": cp,
            "nombreUsuario": nombre,
            "edad": edad,
            "email": email,
            "id": id,
            "planesApuntados": planesApuntados,
            "sexo": sexo

        }).then(function() {

        }).catch((function(error) {
            alert(error);
        }));

    });
}


function eliminarItemArray(array, item) {

    var indice = array.indexOf(item);

    if (indice !== -1) {
        array.splice(indice, 1);
    }
    return array;
}


function apuntarseUsuario(id_plan, descripcion, dueno, fecha, hora, imagen, imgDueno, precio, nombre, ubicacion, usuariosApuntados) {

    var id_usuario = firebase.auth().currentUser.uid;
    var db = firebase.firestore();

    if (typeof usuariosApuntados === 'undefined')
        usuariosApuntados = [];

    //agregamos al plan el usuario y actualizamos
    usuariosApuntados.push(id_usuario);

    var plan = {
        "nombre": nombre,
        "imagen": imagen,
        "ubicacion": ubicacion,
        "fecha": fecha,
        "hora": hora,
        "imagen_dueno": imgDueno,
        "dueno": dueno,
        "precio": precio,
        "descripcion": descripcion,
        "usuarios_apuntados": usuariosApuntados
    }

    db.collection("planes").doc(id_plan).set({
        plan
    }).then(function() {
        console.log("usuario agregado al plan");
    }).catch(function(error) {
        console.log("no se ha podido escribir en firestore:\n " + error);
    });


    return false;
}

function desapuntarseUsuario(id_plan, descripcion, dueno, fecha, hora, imagen, imgDueno, precio, nombre, ubicacion, usuariosApuntados) {
    var idUser = firebase.auth().currentUser.uid;
    var db = firebase.firestore();

    //quitamos del plan el usuario y actualizamos
    usuariosApuntados = eliminarItemArray(usuariosApuntados, idUser);

    var plan = {
        "descripcion": descripcion,
        "dueno": dueno,
        "fecha": fecha,
        "hora": hora,
        "imagen": imagen,
        "imagen_dueno": imgDueno,
        "nombre": nombre,
        "precio": precio,
        "ubicacion": ubicacion,
        "usuarios_apuntados": usuariosApuntados
    }
    db.collection("planes").doc(id_plan).update({
        plan
    }).then(function() {
        console.log("usuario desapuntado del plan");
    }).catch(function(error) {
        console.log("no se ha podido escribir en firestore:\n " + error);
    });

    return false;
}

function irCorreo() {

    var id_usuario = firebase.auth().currentUser.uid;
    var db = firebase.database();

    db.ref(id_usuario).once('value', function(snapshot) {
        var datos = snapshot.val();
        var nombre = datos.nombreUsuario;
        var email = datos.email;

        var link = "mailto:1998informatica1998@gmail.com" +
            "?cc=" + email +
            "&subject=" + escape("Duda de " + nombre) +
            "&body=";

        window.location.href = link;
    });



}