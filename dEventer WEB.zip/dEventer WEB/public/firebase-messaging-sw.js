  importScripts("https://www.gstatic.com/firebasejs/7.2.3/firebase-app.js");
  importScripts("https://www.gstatic.com/firebasejs/7.2.3/firebase-messaging.js");

  const config = {
      apiKey: "AIzaSyAP7zusaSm2vzMEhXWYFXKawrcBVSIopF8",
      authDomain: "deventer-bc2dc.firebaseapp.com",
      databaseURL: "https://deventer-bc2dc.firebaseio.com",
      projectId: "deventer-bc2dc",
      storageBucket: "deventer-bc2dc.appspot.com",
      messagingSenderId: "783803074162",
      appId: "1:783803074162:web:b9d8685fc899737543a4eb",
      measurementId: "G-L47JNGS0M0"
  };

  firebase.initializeApp(config);

  const messaging = firebase.messaging();

  messaging.setBackgroundMessageHandler(function(payload) {
      console.log('Mensaje en Background ', payload);

      return self.registration.showNotification(payload.data.title, {
          body: payload.data.body,
          icon: payload.data.icon,
          data: payload.data.link
      });
  });

  /* self.addEventListener('notificationclick', function(event) {
      event.notification.close();
      event.waitUntil(self.clients.openWindow(event.notification.data)); */

  self.addEventListener('notificationclick', function(event) {
      event.notification.close();
      clients.openWindow("https://deventer-bc2dc.web.app/chat.html");
  });