$(document).ready(function() {
    $('#nav').load('estructura/header.html');
});